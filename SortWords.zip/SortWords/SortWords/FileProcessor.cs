﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SortWords
{
    public class FileProcessor: IFileProcessor
    {
        private IFilePath _path;
        private IFileReader _reader;
        private IStringProcessor _stringProcessor;
        private Iprint _print;
        
        private string _processedText = string.Empty;
        private string _message = string.Empty;

        public FileProcessor(IFilePath path, IFileReader reader, IStringProcessor stringProcessor, Iprint print)
        {
            _path = path;
            _reader = reader;
            _stringProcessor = stringProcessor;
            _print = print;                        
        }

        public string Message 
        {
            get
            {
                return _message;
            }            
        }

        public string ProcessedText
        {
            get
            {
                return _processedText;
            }
        }

        public bool ProcessFile(string fileName, int topCount)
        {
            // get full file path                            
            string filePath = _path.GetFilePathFromFileName(fileName);

            // read file
            string sourceText = _reader.ReadFile(filePath);

            if (!string.IsNullOrWhiteSpace(sourceText))
            {
                // process file content
                _stringProcessor.TopCount = topCount;
                _processedText = _stringProcessor.ProcessString(sourceText);
            }
            else
            {
                _message = _print.EmptyFileMessage();
                return false;
            } 

            return true;
        }
    }
}
