﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SortWords
{
    public class Print: Iprint
    {
        public string ApplicationEndMessage()
        {
            return "Press any key to Exit...";
        }

        public string EmptyFileMessage()
        {
            return "File is Empty or Not Found.";
        }

        public string FileNotFoundMessage()
        {
            return "File Not Provided.";
        }
    }
}
