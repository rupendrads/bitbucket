﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace SortWords
{
    public interface Iprint
    {
        string ApplicationEndMessage();
        string EmptyFileMessage();
        string FileNotFoundMessage();
    }
}
