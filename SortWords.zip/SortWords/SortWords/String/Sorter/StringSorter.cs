﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SortWords
{
    public class StringSorter : IStringSorter
    {
        public string[] SortByAphabet(string[] wordsArray)
        {
            var resultArray = wordsArray;
            Array.Sort(resultArray);
            return resultArray;
        }

        public string[] SortByNumber(string[] wordsArray)
        {
            Dictionary<string, int> wordsDictionary = new Dictionary<string, int>();

            for (int i = 0; i < wordsArray.Length; i++)
            {
                var item = wordsArray[i].Split(new char[] { '-' });
                string key = item[1];
                int value =Convert.ToInt32(item[0]);
                wordsDictionary.Add(key, value);                
            }
             
            List<string> result = new List<string>();

            foreach (var word in wordsDictionary.OrderBy(word => word.Value))
            {
                result.Add(word.Value + "-" + word.Key);
            }

            return result.ToArray();
        }

        public string[] Reverse(string[] wordsArray)
        {
            var result = wordsArray;
            Array.Reverse(result);
            return result;
        }
    }
}
