﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SortWords
{
    public interface IStringSorter
    {
        string[] SortByAphabet(string[] wordsArray);
        string[] SortByNumber(string[] wordsArray);
        string[] Reverse(string[] wordsArray);
    }
}
