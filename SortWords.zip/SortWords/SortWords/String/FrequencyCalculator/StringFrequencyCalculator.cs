﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SortWords
{
    public class StringFrequencyCalculator: IStringFrequencyCalculator
    {
        public string[] CountUniqueFrequency(string[] wordsArray)
        {
            Dictionary<string, int> wordsDictionary = new Dictionary<string, int>();

            for (int i = 0; i < wordsArray.Length; i++)
            {
                if (wordsDictionary.ContainsKey(wordsArray[i]))
                {
                    wordsDictionary[wordsArray[i]] = wordsDictionary[wordsArray[i]] + 1;
                }
                else
                {
                    wordsDictionary.Add(wordsArray[i], 1);
                }
            }

            List<string> result = new List<string>();

            foreach (var word in wordsDictionary)
            {
                result.Add(word.Value + "-" + word.Key);
            }

            return result.ToArray();
        }
    }
}
