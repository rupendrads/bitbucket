﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SortWords
{
    public class StringSplitter: IStringSplitter
    {
        public string[] SplitToWordsArray(string text)
        {
            string[] resultText = text.Split(new char[] { '.', '?', '!', ' ', ';', ':', ',' }, StringSplitOptions.RemoveEmptyEntries);

            return resultText;
        }

        public string[] Split(string text, char seperator)
        {
            string[] resultText = text.Split(new char[] { ' ' });

            return resultText;
        }
    }
}
