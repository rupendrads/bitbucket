﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SortWords
{
    public interface IStringSplitter
    {
        string[] SplitToWordsArray(string text);
        string[] Split(string text, char seperator);
    }
}
