﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SortWords
{
    public class StringProcesser: IStringProcessor
    {
        IStringFilter _filter;
        IStringSplitter _splitter;
        IStringSorter _sorter;
        IStringFrequencyCalculator _frequencyCalculator;

        public int TopCount { get; set; } 

        public StringProcesser(IStringFilter filter, IStringSplitter splitter, IStringSorter sorter, IStringFrequencyCalculator frequencyCalculator)
        {
            _filter = filter;
            _splitter = splitter;
            _sorter = sorter;
            _frequencyCalculator = frequencyCalculator;

            this.TopCount = 20;
        }

        public string ProcessString(string sourceText)
        {
            // filter (a-z A-Z)
            string filteredText = _filter.FilterAlphabets(sourceText);

            // split text to array
            string[] wordsArray = _splitter.SplitToWordsArray(filteredText);

            // sort by alphabet
            wordsArray = _sorter.SortByAphabet(wordsArray);

            // get unique words with frequency
            wordsArray = _frequencyCalculator.CountUniqueFrequency(wordsArray);

            // sort by frequency number
            wordsArray = _sorter.SortByNumber(wordsArray);

            // reverse the order of frequency number
            wordsArray = _sorter.Reverse(wordsArray);

            // get top words
            wordsArray = _filter.GetTopWords(this.TopCount, wordsArray);

            // convert string array to string
            filteredText = String.Join(" ", wordsArray);

            return filteredText.Trim();
        }
    }
}
