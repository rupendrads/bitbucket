﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;

namespace SortWords
{
    public class StringFilter: IStringFilter
    {
        private string searchPattern = "[^A-Za-z ]";

        public string FilterAlphabets(string text)
        {
            Regex searchTerm = new Regex(searchPattern);
            var result = searchTerm.Replace(text, "");           

            return result;
        }

        public string[] GetTopWords(int number, string[] wordsArray)
        {
            string[] resultArray = wordsArray;
            int lengthToRemove = resultArray.Length - number;

            Array.Clear(resultArray, number, lengthToRemove);

            return resultArray;
        }
    }
}
