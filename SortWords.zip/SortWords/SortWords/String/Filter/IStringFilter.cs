﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SortWords
{
    public interface IStringFilter
    {
        string FilterAlphabets(string text);
        string[] GetTopWords(int number, string[] wordsArray);
    }
}
