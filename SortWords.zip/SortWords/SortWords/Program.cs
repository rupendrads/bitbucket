﻿using Ninject;
using Ninject.Parameters;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;

namespace SortWords
{
    class Program
    {
        internal static IKernel kernel = new StandardKernel();

        static void Main(string[] args)
        {
            try
            {
                // load ninject module
                kernel.Load(Assembly.GetExecutingAssembly());

                Iprint print = kernel.Get<Iprint>();

                string fileType = ConfigurationManager.AppSettings["fileType"].ToString().ToLower(); // Text or Binary

                int topCount = 20;

                // if parameter passed at command prompt
                if (args.Count() > 0)
                {
                    // get file name from command parameter
                    string fileName = args[0];

                    // process file
                    var reader = new ConstructorArgument("reader", kernel.Get<IFileReader>(fileType));
                    var fileProcessor = kernel.Get<IFileProcessor>(reader);

                    if (fileProcessor.ProcessFile(fileName, topCount))
                    {
                        var splitter = kernel.Get<IStringSplitter>();

                        string[] output = splitter.Split(fileProcessor.ProcessedText, ' ');

                        foreach (var word in output)
                        {
                            Console.WriteLine(word);
                        }
                    }
                    else
                    {
                        Console.WriteLine(fileProcessor.Message);
                    }
                }
                else
                {
                    Console.WriteLine(print.FileNotFoundMessage());
                }

                Console.WriteLine(print.ApplicationEndMessage());
            }
            catch (Exception ex)
            {
                Console.WriteLine();
                Console.WriteLine("Error occured while processing the file.");
                Console.WriteLine();
                Console.WriteLine("Please check the file type in configuration file (value: text or binary).");
                Console.WriteLine("Input only file name which type match with the type defined in .config file.");
                Console.WriteLine();
                Console.WriteLine("Press any key to exit...");
            }

            Console.ReadLine();
        }
    }
}
