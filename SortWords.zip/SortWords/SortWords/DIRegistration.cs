﻿using Ninject;
using Ninject.Modules;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SortWords
{
    public class DIRegistration : NinjectModule
    {
        public override void Load()
        {            
            Bind<IStringSplitter>().To<StringSplitter>();
            Bind<IStringFilter>().To<StringFilter>();
            Bind<IStringSorter>().To<StringSorter>();
            Bind<IStringFrequencyCalculator>().To<StringFrequencyCalculator>();
            Bind<IStringProcessor>().To<StringProcesser>();
            
            Bind<IFilePath>().To<FilePath>();
            Bind<IFileReader>().To<TextFileReader>().Named("text");
            Bind<IFileReader>().To<BinaryFileReader>().Named("binary");

            Bind<IFileProcessor>().To<FileProcessor>();
            Bind<Iprint>().To<Print>();            
        }
    }
}
