﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SortWords
{
    public class BinaryFileReader: IFileReader
    {
        public string ReadFile(string filePath)
        {
            string binaryText = string.Empty;
            string stringText = string.Empty;
            List<Byte> byteList = new List<Byte>();

            if (File.Exists(filePath))
            {
                binaryText = File.ReadAllText(filePath);

                for (int i = 0; i < binaryText.Length; i += 8)
                {
                    byteList.Add(Convert.ToByte(binaryText.Substring(i, 8), 2));
                }

                stringText = Encoding.ASCII.GetString(byteList.ToArray());
            }

            return stringText;
        }
    }
}
