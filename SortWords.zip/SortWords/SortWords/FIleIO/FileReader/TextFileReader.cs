﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SortWords
{
    public class TextFileReader: IFileReader
    {
        public string ReadFile(string filePath)
        {
            string text = string.Empty;

            if (File.Exists(filePath))
            {
                text = File.ReadAllText(filePath);
            }

            return text;
        }
    }
}
