﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;

namespace SortWords
{
    public class FilePath: IFilePath
    {
        // Assumption: file is placed at the exe path
        public string GetFilePathFromFileName(string fileName)
        {
            string filePath;

            // get currently executing assembly directory
            Assembly assembly = Assembly.GetExecutingAssembly();
            string assemblyDir = assembly.CodeBase;
            assemblyDir = assemblyDir.Replace("file:///", "");
            assemblyDir = Path.GetDirectoryName(assemblyDir);

            // add filename to get full file path
            filePath = assemblyDir + "\\" + fileName;

            return filePath;
        }
    }
}
