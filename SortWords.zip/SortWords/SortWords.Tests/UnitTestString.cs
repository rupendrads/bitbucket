﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Ninject;
using System.Reflection;
using Ninject.Parameters;

namespace SortWords.Tests
{
    [TestClass]
    public class UnitTestString
    {        
        string filePath = "Mobydick-Binary.txt";
        string fileType = "binary";

        IKernel kernel = new StandardKernel();

        private void Bind()
        {
           kernel.Load(new DIRegistration());
        }

        public UnitTestString()
        {
            Bind();
        }

        [TestMethod]
        public void FilterAlphabets()
        {
            // Arrange
            string text = "Box  2782 Champaign, *** IL 61825 When all other email fails. .";
            var filter = kernel.Get<IStringFilter>();

            // Act
            string result = filter.FilterAlphabets(text);

            // Assert
            Assert.IsFalse(result.Contains("2782"));
            Assert.IsFalse(result.Contains("61825"));
            Assert.IsFalse(result.Contains("***"));
        }

        [TestMethod]
        public void SplitToWordsArray()
        {
            // Arrange
            string text = "Why; :! This?,.";
            var splitter = kernel.Get<IStringSplitter>();

            // Act
            string[] result = splitter.SplitToWordsArray(text);

            // Assert
            Assert.IsTrue(result.Length == 2);
            Assert.AreEqual("Why", result[0]);
            Assert.AreEqual("This", result[1]);
        }

        [TestMethod]
        public void SortByAlphabet()
        {
            // Arrange
            string[] wordsArray = new string[] { "Box", "Champaign", "IL", "When", "all", "other", "email", "fails" };
            var sorter = kernel.Get<IStringSorter>();

            // Act
            var result = sorter.SortByAphabet(wordsArray);

            // Assert
            Assert.IsTrue(wordsArray.Length == result.Length);
            Assert.AreEqual(result[0], "all");
            Assert.AreEqual(result[result.Length - 1], "When");
        }

        [TestMethod]
        public void CountUniqueFrequency()
        {
            // Arrange
            string[] wordsArray = new string[] { "all", "Box", "Box", "Champaign", "email", "email", "email", "email", "fails", "fails", "fails", "IL", "IL", "other", "When" };
            var frequencyCalculator = kernel.Get<IStringFrequencyCalculator>();

            // Act
            var result = frequencyCalculator.CountUniqueFrequency(wordsArray);

            // Assert
            Assert.AreEqual("1-all", result[0]);
            Assert.AreEqual("2-Box", result[1]);
            Assert.AreEqual("1-Champaign", result[2]);
            Assert.AreEqual("4-email", result[3]);
            Assert.AreEqual("3-fails", result[4]);
            Assert.AreEqual("2-IL", result[5]);
            Assert.AreEqual("1-other", result[6]);
            Assert.AreEqual("1-When", result[7]);
        }

        [TestMethod]
        public void SortByNumber()
        {
            // Arrange
            string[] wordsArray = new string[] { "2-Box", "1-Champaign", "8-IL", "3-When", "2-all", "1-other", "4-email", "3-fails" };
            var sorter = kernel.Get<IStringSorter>();

            // Act
            var result = sorter.SortByNumber(wordsArray);

            // Assert
            Assert.AreEqual(result[0], "1-Champaign");
            Assert.AreEqual(result[result.Length - 1], "8-IL");
        }

        [TestMethod]
        public void Reverse()
        {
            // Arrange
            string[] wordsArray = new string[] { "1-Champaign", "1-other", "2-Box", "2-all", "3-fails", "3-When", "4-email", "8-IL" };
            var sorter = kernel.Get<IStringSorter>();

            // Act
            var result = sorter.Reverse(wordsArray);

            // Assert
            Assert.AreEqual(result[0], "8-IL");
            Assert.AreEqual(result[result.Length - 1], "1-Champaign");
        }

        [TestMethod]
        public void GetTopWords()
        {
            // Arrange
            string[] wordsArray = new string[] { "Box", "Champaign", "IL", "When", "all", "other", "email", "fails" };
            int topNumber = 5;
            var filter = kernel.Get<IStringFilter>();

            // Act
            string[] resultArray = filter.GetTopWords(topNumber, wordsArray);
            string resultText = String.Join(" ", resultArray).Trim();

            // Assert
            Assert.IsTrue(string.IsNullOrEmpty(resultArray[5]));
            Assert.AreEqual("Box Champaign IL When all", resultText); 
        }

        [TestMethod]
        public void ProcessString()
        {
            // Arrange
            var path = kernel.Get<IFilePath>();
            var reader = kernel.Get<IFileReader>(fileType.ToLower());
            var processor = kernel.Get<IStringProcessor>();
            string fullPath = path.GetFilePathFromFileName(filePath);
            string text = reader.ReadFile(fullPath);

            // Act
            string result = processor.ProcessString(text);
            string[] resultArray = result.Split(new char[] { ' ' });

            // Assert
            Assert.IsTrue(!string.IsNullOrWhiteSpace(result));
            Assert.IsTrue(resultArray.Length > 0);
        }

        [TestMethod]
        public void ProcessFile()
        {
            // Arrange
            var reader = new ConstructorArgument("reader", kernel.Get<IFileReader>(fileType.ToLower()));
            var fileProcessor = kernel.Get<IFileProcessor>(reader);

            // Act
            bool result = fileProcessor.ProcessFile(filePath, 20);

            // Assert
            Assert.IsTrue(result);
            Assert.IsFalse(string.IsNullOrWhiteSpace(fileProcessor.ProcessedText));
            Assert.IsTrue(string.IsNullOrEmpty(fileProcessor.Message));
        }

        [TestMethod]
        public void ProcessEmptyFile()
        {
            // Arrange
            var reader = new ConstructorArgument("reader", kernel.Get<IFileReader>(fileType.ToLower()));
            var fileProcessor = kernel.Get<IFileProcessor>(reader);

            // Act
            bool result = fileProcessor.ProcessFile("xyz", 20);

            // Assert
            Assert.IsFalse(result);
            Assert.IsTrue(string.IsNullOrWhiteSpace(fileProcessor.ProcessedText));
            Assert.IsFalse(string.IsNullOrEmpty(fileProcessor.Message));
        }

        [TestMethod]
        public void Split()
        {
            // Arrange
            var splitter = kernel.Get<IStringSplitter>();

            // Act
            string[] result = splitter.Split("40 ABC", ' ');

            // Assert
            Assert.IsTrue(result.Length == 2);
            Assert.AreEqual("40", result[0]);
            Assert.AreEqual("ABC", result[1]);
        }
    }
}
