﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace SortWords.Tests
{
    [TestClass]
    public class UnitTestPrint
    {
        // Arrange
        Iprint print = new Print();

        [TestMethod]
        public void ApplicationEndMessage()
        {
            // Act
            string message = print.ApplicationEndMessage();

            // Assert
            Assert.IsFalse(string.IsNullOrWhiteSpace(message));
            Assert.AreEqual("Press any key to Exit...", message);
        }

        [TestMethod]
        public void EmptyFileMessage()
        {
            // Act
            string message = print.EmptyFileMessage();

            // Assert
            Assert.IsFalse(string.IsNullOrWhiteSpace(message));
            Assert.AreEqual("File is Empty or Not Found.", message);
        }

        [TestMethod]
        public void FileNotFoundMessage()
        {
            // Act
            string message = print.FileNotFoundMessage();

            // Assert
            Assert.IsFalse(string.IsNullOrWhiteSpace(message));
            Assert.AreEqual("File Not Provided.", message);
        }
    }
}
