﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace SortWords.Tests
{
    [TestClass]
    public class UnitTestFileIO
    {
        // Arrange
        string binaryFilePath = "Mobydick-Binary.txt";
        string textFilePath = "Mobydick.txt";
        string executableDirectory = @"E:\";
        string outPutStartWith = "**The";
        string outPutEndWith = "o";

        IFilePath path = new FilePath();
        IFileReader binaryReader = new BinaryFileReader();
        IFileReader textReader = new TextFileReader();

        [TestMethod]
        public void GetFilePathFromFileName()
        {
            // Act
            string result = path.GetFilePathFromFileName(textFilePath);

            // Assert
            Assert.IsTrue(!string.IsNullOrWhiteSpace(result));
            Assert.IsTrue(result.EndsWith(textFilePath));
            Assert.IsTrue(result.StartsWith(executableDirectory));
        }

        [TestMethod]
        public void ReadTextFile()
        {
            // Arrange
            var fullFilePath = path.GetFilePathFromFileName(textFilePath);

            // Act
            string result = textReader.ReadFile(fullFilePath);

            // Assert
            Assert.IsFalse(string.IsNullOrWhiteSpace(result));
            Assert.IsTrue(result.StartsWith(outPutStartWith));
            Assert.IsTrue(result.Trim().EndsWith(outPutEndWith));
        }

        [TestMethod]
        public void ReadBinaryFile()
        {
            // Arrange
            var fullFilePath = path.GetFilePathFromFileName(binaryFilePath);

            // Act
            string result = binaryReader.ReadFile(fullFilePath);

            // Assert
            Assert.IsFalse(string.IsNullOrWhiteSpace(result));
            Assert.IsTrue(result.StartsWith(outPutStartWith));
            Assert.IsTrue(result.Trim().EndsWith(outPutEndWith));
        }
    }
}
